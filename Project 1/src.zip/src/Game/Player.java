package Game;

public class Player {

	private int id;
	private double val;
	
	public Player(int n, double v){
		this.id = n;
		this.val = v;		
	}

	public int getId() {
		return id;
	}

	public double getVal() {
		return val;
	}
	
}
